package com.southwind.form;

import lombok.Data;

@Data
public class AdminForm {
    private String username;
    private String password;
}
