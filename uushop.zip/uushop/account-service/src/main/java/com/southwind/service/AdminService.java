package com.southwind.service;

import com.southwind.entity.Admin;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author southwind
 * @since 2025-02-19
 */
public interface AdminService extends IService<Admin> {

}
