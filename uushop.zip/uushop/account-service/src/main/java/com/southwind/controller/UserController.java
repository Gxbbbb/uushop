package com.southwind.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.southwind.entity.User;
import com.southwind.exception.ShopException;
import com.southwind.form.UserForm;
import com.southwind.form.UserLoginForm;
import com.southwind.result.ResponseEnum;
import com.southwind.service.UserService;
import com.southwind.util.JwtUtil;
import com.southwind.util.MD5Util;
import com.southwind.util.RegexValidateUtil;
import com.southwind.util.ResultVOUtil;
import com.southwind.vo.ResultVO;
import com.southwind.vo.UserVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import org.springframework.stereotype.Controller;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author southwind
 * @since 2025-02-19
 */
@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/register")
    public ResultVO register(@RequestBody UserForm userForm){
        //非空校验
        if(userForm.getCode() == null) throw new ShopException(ResponseEnum.ACCOUNT_CODE_ERROR.getMsg());
        if(userForm.getPassword() == null) throw new ShopException(ResponseEnum.ACCOUNT_PASSWORD_ERROR.getMsg());
        if(userForm.getMobile() == null) throw new ShopException(ResponseEnum.ACCOUNT_MOBILE_ERROR.getMsg());
        if(!RegexValidateUtil.checkMobile(userForm.getMobile())) throw new ShopException(ResponseEnum.MOBILE_ERROR.getMsg());
        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("mobile", userForm.getMobile());
        User user = this.userService.getOne(queryWrapper);
        if(user != null) throw new ShopException(ResponseEnum.MOBILE_EXIST.getMsg());
        User user1 = new User();
        user1.setPassword(MD5Util.getSaltMD5(userForm.getPassword()));
        user1.setMobile(userForm.getMobile());
        boolean save = this.userService.save(user1);
        if(save) return ResultVOUtil.success(null);
        return ResultVOUtil.fail(ResponseEnum.USER_REGISTER_FAIL.getMsg());
    }

    @GetMapping("/login")
    public ResultVO login(UserLoginForm userLoginForm){
        if(!RegexValidateUtil.checkMobile(userLoginForm.getMobile())) throw new ShopException(ResponseEnum.MOBILE_ERROR.getMsg());
        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("mobile", userLoginForm.getMobile());
        User user = this.userService.getOne(queryWrapper);
        if(user == null) throw new ShopException(ResponseEnum.MOBILE_NULL.getMsg());
        if(!MD5Util.getSaltverifyMD5(userLoginForm.getPassword(), user.getPassword())) throw new ShopException(ResponseEnum.PASSWORD_ERROR.getMsg());
        UserVO userVO = new UserVO();
        userVO.setUserId(user.getUserId());
        userVO.setPassword(user.getPassword());
        userVO.setMobile(user.getMobile());
        userVO.setToken(JwtUtil.createToken(user.getUserId(), user.getMobile()));
        return ResultVOUtil.success(userVO);
    }

    @GetMapping("/checkToken/{token}")
    public ResultVO checkToken(@PathVariable("token") String token){
        boolean checkToken = JwtUtil.checkToken(token);
        if(checkToken) return ResultVOUtil.success(null);
        return ResultVOUtil.fail(ResponseEnum.TOKEN_ERROR.getMsg());
    }

}

