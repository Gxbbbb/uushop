package com.southwind.mapper;

import com.southwind.entity.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author southwind
 * @since 2025-02-19
 */
public interface UserMapper extends BaseMapper<User> {

}
