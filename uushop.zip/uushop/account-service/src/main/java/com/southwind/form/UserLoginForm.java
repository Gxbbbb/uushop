package com.southwind.form;

import lombok.Data;

@Data
public class UserLoginForm {
    private String mobile;
    private String password;
}
