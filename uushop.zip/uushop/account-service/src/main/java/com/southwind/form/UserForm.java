package com.southwind.form;

import lombok.Data;

@Data
public class UserForm {
    private Integer code;
    private String mobile;
    private String password;
}
