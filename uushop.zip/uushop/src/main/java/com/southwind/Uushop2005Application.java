package com.southwind;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Uushop2005Application {

    public static void main(String[] args) {
        SpringApplication.run(Uushop2005Application.class, args);
    }

}
