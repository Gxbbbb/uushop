package com.southwind.vo;

import lombok.Data;

import java.util.List;

@Data
public class LineVO {
    private String name;
    private String type = "line";
    private String stack = "销量";
    private List<Integer> data;
}
