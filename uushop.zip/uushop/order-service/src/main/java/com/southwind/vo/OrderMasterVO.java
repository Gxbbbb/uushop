package com.southwind.vo;

import com.southwind.entity.OrderMaster;
import lombok.Data;

import java.util.List;

@Data
public class OrderMasterVO extends OrderMaster {
    private List<OrderDetailVO> orderDetailList;
}
