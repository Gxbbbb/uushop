package com.southwind.service;

import com.southwind.entity.OrderDetail;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.Map;

/**
 * <p>
 * 订单详情表 服务类
 * </p>
 *
 * @author southwind
 * @since 2025-02-14
 */
public interface OrderDetailService extends IService<OrderDetail> {
    public Map bar();
    public Map baseLine();
    public Map stackedLine();
}
