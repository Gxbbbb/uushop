package com.southwind.mapper;

import com.southwind.entity.OrderDetail;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.southwind.vo.BarVO;
import com.southwind.vo.QueryVO;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * <p>
 * 订单详情表 Mapper 接口
 * </p>
 *
 * @author southwind
 * @since 2025-02-14
 */
public interface OrderDetailMapper extends BaseMapper<OrderDetail> {

    @Select({"select product_name name,count(product_name) value from order_detail group by product_name"})
    public List<BarVO> barList();

    @Select({"select DATE_FORMAT(create_time, '%Y-%m-%d') name,count(create_time) value from order_detail group by DATE_FORMAT(create_time, '%Y-%m-%d')"})
    public List<BarVO> baseLine();

    @Select({"select product_name from product_info"})
    public List<String> productNames();

    @Select({"select distinct DATE_FORMAT(order_detail.create_time, '%Y-%m-%d') as dd from order_detail"})
    public List<String> date();

    @Select({"select product_name as name,mm.dd as date,(\n" +
            "    select COALESCE(sum(product_quantity),0)\n" +
            "    from order_detail where\n" +
            "    pi.product_id = order_detail.product_id and\n" +
            "    DATE_FORMAT(order_detail.create_time, '%Y-%m-%d') = mm.dd\n" +
            "    ) as count\n" +
            "from product_info pi,\n" +
            "     (select distinct DATE_FORMAT(order_detail.create_time, '%Y-%m-%d') as dd from order_detail)\n" +
            "         as mm\n" +
            "where pi.product_name = #{name}  order by mm.dd"})
    public List<QueryVO> query(String name);
}
