package com.southwind.form;

import lombok.Data;

@Data
public class OrderInnerForm {
    private Integer productId;
    private Integer productQuantity;
}
