package com.southwind.vo;

import lombok.Data;

@Data
public class QueryVO {
    private String name;
    private String date;
    private Integer count;
}
