package com.southwind.service.impl;

import com.southwind.entity.OrderDetail;
import com.southwind.mapper.OrderDetailMapper;
import com.southwind.service.OrderDetailService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.southwind.util.EChartsColorUtil;
import com.southwind.vo.BarInnerVO;
import com.southwind.vo.BarVO;
import com.southwind.vo.LineVO;
import com.southwind.vo.QueryVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 订单详情表 服务实现类
 * </p>
 *
 * @author southwind
 * @since 2025-02-14
 */
@Service
public class OrderDetailServiceImpl extends ServiceImpl<OrderDetailMapper, OrderDetail> implements OrderDetailService {

    @Autowired
    private OrderDetailMapper orderDetailMapper;

    @Override
    public Map bar() {
        List<BarVO> barVOS = this.orderDetailMapper.barList();
        List<String> names = new ArrayList<>();
        for (BarVO barVO : barVOS) {
            names.add(barVO.getName());
        }
        List<BarInnerVO> values = new ArrayList<>();
        for (BarVO barVO : barVOS) {
            BarInnerVO vo = new BarInnerVO();
            vo.setValue(barVO.getValue());
            vo.setItemStyle(EChartsColorUtil.createItemStyle(barVO.getValue()));
            values.add(vo);
        }
        Map map = new HashMap();
        map.put("names", names);
        map.put("values", values);
        return map;
    }

    @Override
    public Map baseLine() {
        List<BarVO> list = this.orderDetailMapper.baseLine();
        List<String> names = new ArrayList<>();
        List<Integer> values = new ArrayList<>();
        for (BarVO barVO : list) {
            names.add(barVO.getName());
            values.add(barVO.getValue());
        }
        Map map = new HashMap();
        map.put("names", names);
        map.put("values", values);
        return map;
    }

    @Override
    public Map stackedLine() {
        List<String> names = this.orderDetailMapper.productNames();
        List<String> dates = this.orderDetailMapper.date();
        List<LineVO> datas = new ArrayList<>();
        for (String name : names) {
            List<QueryVO> list = this.orderDetailMapper.query(name);
            List<Integer> countList = new ArrayList<>();
            for (QueryVO queryVO : list) {
                countList.add(queryVO.getCount());
            }
            LineVO vo = new LineVO();
            vo.setName(name);
            vo.setData(countList);
            datas.add(vo);
        }
        Map map = new HashMap();
        map.put("names", names);
        map.put("dates", dates);
        map.put("datas", datas);
        return map;
    }
}
