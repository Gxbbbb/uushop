package com.southwind.vo;

import lombok.Data;

import java.util.List;

@Data
public class PageVO {
    private List content;
    private Integer size;
    private Long total;
}
