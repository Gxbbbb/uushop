package com.southwind.vo;

import lombok.Data;

@Data
public class BarVO {
    private String name;
    private Integer value;
}
