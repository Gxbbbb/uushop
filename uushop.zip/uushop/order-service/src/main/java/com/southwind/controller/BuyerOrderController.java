package com.southwind.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.southwind.entity.OrderDetail;
import com.southwind.entity.OrderMaster;
import com.southwind.exception.ShopException;
import com.southwind.form.OrderForm;
import com.southwind.result.ResponseEnum;
import com.southwind.service.OrderDetailService;
import com.southwind.service.OrderMasterService;
import com.southwind.util.ResultVOUtil;
import com.southwind.vo.OrderDetailVO;
import com.southwind.vo.OrderMasterVO;
import com.southwind.vo.ResultVO;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 订单详情表 前端控制器
 * </p>
 *
 * @author southwind
 * @since 2025-02-14
 */
@RestController
@RequestMapping("/buyer/order")
public class BuyerOrderController {

    @Autowired
    private OrderMasterService orderMasterService;
    @Autowired
    private OrderDetailService orderDetailService;

    @PostMapping("/create")
    public ResultVO create(@RequestBody OrderForm orderForm){
        String orderId = this.orderMasterService.create(orderForm);
        Map map = new HashMap();
        map.put("orderId", orderId);
        return ResultVOUtil.success(map);
    }

    @GetMapping("/list/{buyerId}/{page}/{size}")
    public ResultVO list(
            @PathVariable("buyerId") Integer buyerId,
            @PathVariable("page") Integer page,
            @PathVariable("size") Integer size
    ){
        Page<OrderMaster> pageModel = new Page<>(page, size);
        QueryWrapper<OrderMaster> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("buyer_openid", buyerId);
        Page<OrderMaster> resultPage = this.orderMasterService.page(pageModel, queryWrapper);
        List<OrderMaster> records = resultPage.getRecords();
        return ResultVOUtil.success(records);
    }

    @GetMapping("/detail/{buyerId}/{orderId}")
    public ResultVO detail(
            @PathVariable("buyerId") Integer buyerId,
            @PathVariable("orderId") String orderId
    ){
        QueryWrapper<OrderMaster> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("buyer_openid", buyerId);
        queryWrapper.eq("order_id", orderId);
        OrderMaster orderMaster = this.orderMasterService.getOne(queryWrapper);
        QueryWrapper<OrderDetail> queryWrapper1 = new QueryWrapper<>();
        queryWrapper1.eq("order_id", orderId);
        List<OrderDetail> orderDetailList = this.orderDetailService.list(queryWrapper1);
        OrderMasterVO orderMasterVO = new OrderMasterVO();
        BeanUtils.copyProperties(orderMaster, orderMasterVO);
        List<OrderDetailVO> list = new ArrayList<>();
        for (OrderDetail orderDetail : orderDetailList) {
            OrderDetailVO orderDetailVO = new OrderDetailVO();
            BeanUtils.copyProperties(orderDetail, orderDetailVO);
            list.add(orderDetailVO);
        }
        orderMasterVO.setOrderDetailList(list);
        return ResultVOUtil.success(orderMasterVO);
    }

    @PutMapping("/cancel/{buyerId}/{orderId}")
    public ResultVO cancel(@PathVariable("buyerId") Integer buyerId,@PathVariable("orderId") String orderId){
        QueryWrapper<OrderMaster> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("buyer_openid", buyerId);
        queryWrapper.eq("order_id", orderId);
        OrderMaster orderMaster = this.orderMasterService.getOne(queryWrapper);
        if(orderMaster == null) throw new ShopException(ResponseEnum.ORDER_NULL.getMsg());
        if(orderMaster.getOrderStatus() != 0) throw new ShopException(ResponseEnum.ORDER_STATUS_ERROR.getMsg());
        orderMaster.setOrderStatus(2);
        boolean updateById = this.orderMasterService.updateById(orderMaster);
        if(updateById) return ResultVOUtil.success(null);
        return ResultVOUtil.fail(ResponseEnum.ORDER_CANCEL_FAIL.getMsg());
    }

    @PutMapping("/finish/{orderId}")
    public ResultVO finish(@PathVariable("orderId") String orderId){
        OrderMaster orderMaster = this.orderMasterService.getById(orderId);
        if(orderMaster == null) throw new ShopException(ResponseEnum.ORDER_NULL.getMsg());
        if(orderMaster.getOrderStatus() != 0) throw new ShopException(ResponseEnum.ORDER_STATUS_ERROR.getMsg());
        orderMaster.setOrderStatus(1);
        boolean updateById = this.orderMasterService.updateById(orderMaster);
        if(updateById) return ResultVOUtil.success(null);
        return ResultVOUtil.fail(ResponseEnum.ORDER_FINISH_FAIL.getMsg());
    }

    @PutMapping("/pay/{buyerId}/{orderId}")
    public ResultVO pay(
            @PathVariable("buyerId") Integer buyerId,
            @PathVariable("orderId") String orderId
    ){
        QueryWrapper<OrderMaster> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("buyer_openid", buyerId);
        queryWrapper.eq("order_id", orderId);
        OrderMaster orderMaster = this.orderMasterService.getOne(queryWrapper);
        if(orderMaster == null) throw new ShopException(ResponseEnum.ORDER_NULL.getMsg());
        if(orderMaster.getOrderStatus() != 0) throw new ShopException(ResponseEnum.ORDER_STATUS_ERROR.getMsg());
        if(orderMaster.getPayStatus() == 1) throw new ShopException(ResponseEnum.ORDER_PAY_ERROR.getMsg());
        orderMaster.setPayStatus(1);
        boolean updateById = this.orderMasterService.updateById(orderMaster);
        if(updateById) return ResultVOUtil.success(null);
        return ResultVOUtil.fail(ResponseEnum.ORDER_PAY_FAIL.getMsg());
    }

}

