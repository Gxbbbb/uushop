package com.southwind.service.impl;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.southwind.entity.OrderDetail;
import com.southwind.entity.OrderMaster;
import com.southwind.entity.ProductInfo;
import com.southwind.exception.ShopException;
import com.southwind.feign.ProductFeign;
import com.southwind.form.OrderForm;
import com.southwind.form.OrderInnerForm;
import com.southwind.mapper.OrderDetailMapper;
import com.southwind.mapper.OrderMasterMapper;
import com.southwind.result.ResponseEnum;
import com.southwind.service.OrderMasterService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.southwind.vo.ResultVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;

import java.math.BigDecimal;

/**
 * <p>
 * 订单表 服务实现类
 * </p>
 *
 * @author southwind
 * @since 2025-02-14
 */
@Service
public class OrderMasterServiceImpl extends ServiceImpl<OrderMasterMapper, OrderMaster> implements OrderMasterService {

    @Autowired
    private ProductFeign productFeign;
    @Autowired
    private OrderMasterMapper orderMasterMapper;
    @Autowired
    private OrderDetailMapper orderDetailMapper;

    @Override
    public String create(OrderForm orderForm) {
        //1、存储OrderMaster
        OrderMaster orderMaster = new OrderMaster();
        orderMaster.setBuyerName(orderForm.getName());
        orderMaster.setBuyerPhone(orderForm.getPhone());
        orderMaster.setBuyerAddress(orderForm.getAddress());
        orderMaster.setBuyerOpenid(orderForm.getId());
        BigDecimal amount = new BigDecimal(0);
        for (OrderInnerForm item : orderForm.getItems()) {
            Integer productId = item.getProductId();
            BigDecimal price = this.productFeign.findPriceById(productId);
            BigDecimal multiply = price.multiply(new BigDecimal(item.getProductQuantity()));
            amount = amount.add(multiply);
        }
        orderMaster.setOrderAmount(amount);
        orderMaster.setOrderStatus(0);
        orderMaster.setPayStatus(0);
        int insert = this.orderMasterMapper.insert(orderMaster);
        //2、存储OrderDetail
        for (OrderInnerForm item : orderForm.getItems()) {
            Integer productId = item.getProductId();
            ProductInfo productInfo = this.productFeign.findById(productId);
            OrderDetail orderDetail = new OrderDetail();
            orderDetail.setOrderId(orderMaster.getOrderId());
            orderDetail.setProductId(item.getProductId());
            orderDetail.setProductName(productInfo.getProductName());
            orderDetail.setProductPrice(productInfo.getProductPrice());
            orderDetail.setProductQuantity(item.getProductQuantity());
            orderDetail.setProductIcon(productInfo.getProductIcon());
            this.orderDetailMapper.insert(orderDetail);
            //3、减库存
            Boolean aBoolean = this.productFeign.subStockById(item.getProductId(), item.getProductQuantity());
            if(!aBoolean) throw new ShopException(ResponseEnum.ORDER_CREATE_ERROR.getMsg());
        }
        return orderMaster.getOrderId();
    }
}
