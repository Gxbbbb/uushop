package com.southwind.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.southwind.entity.OrderMaster;
import com.southwind.exception.ShopException;
import com.southwind.result.ResponseEnum;
import com.southwind.service.OrderDetailService;
import com.southwind.service.OrderMasterService;
import com.southwind.util.ResultVOUtil;
import com.southwind.vo.PageVO;
import com.southwind.vo.ResultVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import org.springframework.stereotype.Controller;

/**
 * <p>
 * 订单表 前端控制器
 * </p>
 *
 * @author southwind
 * @since 2025-02-14
 */
@RestController
@RequestMapping("/seller/order")
public class SellerOrderController {

    @Autowired
    private OrderMasterService orderMasterService;
    @Autowired
    private OrderDetailService orderDetailService;

    @GetMapping("/list/{page}/{size}")
    public ResultVO list(@PathVariable("page") Integer page,@PathVariable("size") Integer size){
        Page<OrderMaster> pageModel = new Page<>(page, size);
        Page<OrderMaster> resultPage = this.orderMasterService.page(pageModel);
        PageVO pageVO = new PageVO();
        pageVO.setContent(resultPage.getRecords());
        pageVO.setSize(size);
        pageVO.setTotal(resultPage.getTotal());
        return ResultVOUtil.success(pageVO);
    }

    @PutMapping("/cancel/{orderId}")
    public ResultVO cancel(@PathVariable("orderId") String orderId){
        OrderMaster orderMaster = this.orderMasterService.getById(orderId);
        if(orderMaster == null) throw new ShopException(ResponseEnum.ORDER_NULL.getMsg());
        if(orderMaster.getOrderStatus() != 0) throw new ShopException(ResponseEnum.ORDER_STATUS_ERROR.getMsg());
        orderMaster.setOrderStatus(2);
        boolean updateById = this.orderMasterService.updateById(orderMaster);
        if(updateById) return ResultVOUtil.success(null);
        return ResultVOUtil.fail(ResponseEnum.ORDER_CANCEL_FAIL.getMsg());
    }

    @PutMapping("/finish/{orderId}")
    public ResultVO finish(@PathVariable("orderId") String orderId){
        OrderMaster orderMaster = this.orderMasterService.getById(orderId);
        if(orderMaster == null) throw new ShopException(ResponseEnum.ORDER_NULL.getMsg());
        if(orderMaster.getOrderStatus() != 0) throw new ShopException(ResponseEnum.ORDER_STATUS_ERROR.getMsg());
        orderMaster.setOrderStatus(1);
        boolean updateById = this.orderMasterService.updateById(orderMaster);
        if(updateById) return ResultVOUtil.success(null);
        return ResultVOUtil.fail(ResponseEnum.ORDER_FINISH_FAIL.getMsg());
    }

    @GetMapping("/barSale")
    public ResultVO barSale(){
        return ResultVOUtil.success(this.orderDetailService.bar());
    }

    @GetMapping("/basicLineSale")
    public ResultVO basicLineSale(){
        return ResultVOUtil.success(this.orderDetailService.baseLine());
    }

    @GetMapping("/stackedLineSale")
    public ResultVO stackedLineSale(){
        return ResultVOUtil.success(this.orderDetailService.stackedLine());
    }
}

