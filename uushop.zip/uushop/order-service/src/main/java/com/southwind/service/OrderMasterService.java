package com.southwind.service;

import com.southwind.entity.OrderMaster;
import com.baomidou.mybatisplus.extension.service.IService;
import com.southwind.form.OrderForm;

/**
 * <p>
 * 订单表 服务类
 * </p>
 *
 * @author southwind
 * @since 2025-02-14
 */
public interface OrderMasterService extends IService<OrderMaster> {
    public String create(OrderForm orderForm);
}
