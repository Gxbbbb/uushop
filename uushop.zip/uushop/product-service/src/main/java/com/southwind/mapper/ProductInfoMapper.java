package com.southwind.mapper;

import com.southwind.entity.ProductInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 商品表 Mapper 接口
 * </p>
 *
 * @author southwind
 * @since 2025-02-12
 */
public interface ProductInfoMapper extends BaseMapper<ProductInfo> {

}
