package com.southwind.form;

import lombok.Data;

@Data
public class SellerCategoryForm {
    private Integer categoryId;
    private String categoryName;
    private Integer categoryType;
}
