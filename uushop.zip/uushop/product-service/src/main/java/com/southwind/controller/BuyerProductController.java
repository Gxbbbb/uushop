package com.southwind.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.southwind.entity.ProductCategory;
import com.southwind.entity.ProductInfo;
import com.southwind.exception.ShopException;
import com.southwind.result.ResponseEnum;
import com.southwind.service.ProductCategoryService;
import com.southwind.service.ProductInfoService;
import com.southwind.util.ResultVOUtil;
import com.southwind.vo.ProductInfoVO;
import com.southwind.vo.ProductVO;
import com.southwind.vo.ResultVO;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import org.springframework.stereotype.Controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * 类目表 前端控制器
 * </p>
 *
 * @author southwind
 * @since 2025-02-12
 */
@RestController
@RequestMapping("/buyer/product")
public class BuyerProductController {

    @Autowired
    private ProductCategoryService categoryService;
    @Autowired
    private ProductInfoService infoService;

    @GetMapping("/list")
    public ResultVO list(){
        List<ProductCategory> productCategoryList = this.categoryService.list();
        List<ProductVO> list = new ArrayList<>();
        for (ProductCategory productCategory : productCategoryList) {
            ProductVO productVO = new ProductVO();
            productVO.setName(productCategory.getCategoryName());
            productVO.setType(productCategory.getCategoryType());
            QueryWrapper<ProductInfo> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("category_type", productCategory.getCategoryType());
            List<ProductInfo> productInfoList = this.infoService.list(queryWrapper);
            List<ProductInfoVO> goods = new ArrayList<>();
            for (ProductInfo productInfo : productInfoList) {
                ProductInfoVO productInfoVO = new ProductInfoVO();
                BeanUtils.copyProperties(productInfo, productInfoVO);
                goods.add(productInfoVO);
            }
            productVO.setGoods(goods);
            list.add(productVO);
        }
        return ResultVOUtil.success(list);
    }

    @GetMapping("/findPriceById/{id}")
    public BigDecimal findPriceById(@PathVariable("id") Integer id){
        ProductInfo productInfo = this.infoService.getById(id);
        if(productInfo == null) throw new ShopException(ResponseEnum.PRODUCT_NULL.getMsg());
        return productInfo.getProductPrice();
    }

    @GetMapping("/findById/{id}")
    public ProductInfo findById(@PathVariable("id") Integer id){
        ProductInfo productInfo = this.infoService.getById(id);
        if(productInfo == null) throw new ShopException(ResponseEnum.PRODUCT_NULL.getMsg());
        return productInfo;
    }

    @PutMapping("/subStockById/{id}/{quantity}")
    public Boolean subStockById(@PathVariable("id") Integer id,@PathVariable("quantity") Integer quantity){
        return this.infoService.subStockById(id, quantity);
    }

}

