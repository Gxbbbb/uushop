package com.southwind.vo;

import lombok.Data;

import java.util.List;

@Data
public class ProductVO {
    private String name;
    private Integer type;
    private List<ProductInfoVO> goods;
}
