package com.southwind.service.impl;

import com.southwind.entity.ProductCategory;
import com.southwind.mapper.ProductCategoryMapper;
import com.southwind.service.ProductCategoryService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 类目表 服务实现类
 * </p>
 *
 * @author southwind
 * @since 2025-02-12
 */
@Service
public class ProductCategoryServiceImpl extends ServiceImpl<ProductCategoryMapper, ProductCategory> implements ProductCategoryService {

}
