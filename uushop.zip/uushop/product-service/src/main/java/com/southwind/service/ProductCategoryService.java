package com.southwind.service;

import com.southwind.entity.ProductCategory;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 类目表 服务类
 * </p>
 *
 * @author southwind
 * @since 2025-02-12
 */
public interface ProductCategoryService extends IService<ProductCategory> {

}
