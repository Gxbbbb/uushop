package com.southwind.service;

import com.southwind.entity.ProductInfo;
import com.baomidou.mybatisplus.extension.service.IService;

import java.io.InputStream;
import java.util.List;

/**
 * <p>
 * 商品表 服务类
 * </p>
 *
 * @author southwind
 * @since 2025-02-12
 */
public interface ProductInfoService extends IService<ProductInfo> {
    public Boolean subStockById(Integer id,Integer quantity);
    public List<ProductInfo> excleToProductInfoList(InputStream inputStream);
}
