package com.southwind.service;

public interface SmsService {
    public boolean send(String mobile,String code);
}
