package com.southwind.result;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ResponseEnum {

    PRODUCT_NULL(300,"商品信息不存在"),
    PRODUCT_STOCK_NULL(301,"商品库存已清空"),
    PRODUCT_STOCK_ERROR(302,"商品库存不足"),
    ORDER_CREATE_ERROR(303,"创建订单失败"),
    ORDER_NULL(304,"订单不存在"),
    ORDER_STATUS_ERROR(305,"订单状态异常"),
    ORDER_CANCEL_FAIL(306,"订单取消失败"),
    ORDER_FINISH_FAIL(307,"订单完成失败"),
    ORDER_PAY_ERROR(308,"支付状态异常"),
    ORDER_PAY_FAIL(309,"订单支付失败"),
    ACCOUNT_CODE_ERROR(310,"校验码为空"),
    ACCOUNT_PASSWORD_ERROR(311,"用户密码为空"),
    ACCOUNT_MOBILE_ERROR(312,"手机号码为空"),
    MOBILE_ERROR(313,"手机号码格式错误"),
    MOBILE_EXIST(314,"手机号已被注册"),
    USER_REGISTER_FAIL(315,"用户注册失败"),
    MOBILE_NULL(316,"手机号不存在"),
    PASSWORD_ERROR(317,"密码错误"),
    TOKEN_ERROR(318,"Token失效"),
    SMS_SEND_ERROR(319,"短信发送失败"),
    SMS_MOBILE_NULL(320,"手机号为空"),
    SMS_MOBILE_ERROR(321,"手机号码格式错误"),
    PRODUCT_ADD_ERROR(322,"商品添加失败"),
    PRODUCT_DELETE_ERROR(323,"商品删除失败"),
    PRODUCT_STATUS_ERROR(324,"商品状态异常"),
    PRODUCT_STATUS_UPDATE_ERROR(325,"商品状态修改失败"),
    PRODUCT_UPDATE_ERROR(326,"商品修改失败"),
    ADMIN_USERNAME_ERROR(327,"用户名错误"),
    ADMIN_PASSWORD_ERROR(328,"密码错误"),
    FILE_UPLOAD_FAIL(329,"文件上传失败");

    private Integer code;
    private String msg;
}
