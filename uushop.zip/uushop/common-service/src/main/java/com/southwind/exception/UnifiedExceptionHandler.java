package com.southwind.exception;

import com.southwind.util.ResultVOUtil;
import com.southwind.vo.ResultVO;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class UnifiedExceptionHandler {

    @ExceptionHandler(value = Exception.class)
    public ResultVO handlerException(Exception e){
        return ResultVOUtil.fail(e.getMessage());
    }
}
