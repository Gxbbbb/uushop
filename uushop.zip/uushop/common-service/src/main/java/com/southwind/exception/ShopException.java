package com.southwind.exception;

public class ShopException extends RuntimeException {
    public ShopException(String message){
        super(message);
    }
}
